const ZH = {
  'Home': '首页'
}
export default ZH
