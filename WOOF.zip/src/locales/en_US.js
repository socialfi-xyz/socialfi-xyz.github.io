const EN = {
  'Home': 'Home'
};
export default EN
